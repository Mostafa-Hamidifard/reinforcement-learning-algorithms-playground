# -*- coding: utf-8 -*-
"""
Created on Tue Jan  2 13:30:12 2024

@author: Mostafa
"""
import numpy as np
class OFF_MC:
    
    def __init__(self,number_of_action,number_of_states,dicount_factor,alpha,eps):
        self.naction = number_of_action
        self.nstate = number_of_states
        self.gamma = dicount_factor
        self.alpha = alpha
        self.eps = eps
        # self.Q = np.random.normal(0,2,size=(self.nstate,self.naction))
        self.Q = np.zeros((self.nstate,self.naction))
        self.Qb = np.zeros((self.nstate,self.naction))
        
        self.C = np.zeros((self.nstate,self.naction))
        
        
        
    def update(self,state_seq,action_seq,reward_seq,episode):
        if len(state_seq) != len(reward_seq) and len(action_seq) != len(reward_seq):
            raise Exception("sequence length not consistent!")
        
        SS = state_seq
        AA = action_seq
        RR = reward_seq
        G = 0 
        W = 1
        T = len(reward_seq)
        rng = np.arange(T)[::-1]
        for t in rng:
            Rt = RR[t]
            St = int(SS[t])
            At = int(AA[t])
            
            G = self.gamma * G +  Rt
            self.C[St,At] = self.C[St,At] + W
            self.Q[St,At] = self.Q[St,At] + W/(self.C[St,At])*(G - self.Q[St,At])          
            pi_st = np.argmax(self.Q[St,:])
            if At != pi_st:
                break
            W = W* 1/self.prob_b_action(St, At, episode)
        
        ## Updating Qb
        self.Qb = self.Q
        
    def prob_b_action(self, state, action, episode):
        prob = self.eps(episode) / self.naction
        max_action = np.argmax(self.Qb[state,:])
        if self.Qb[state,action] == self.Qb[state,max_action]:
            prob = prob + 1 - self.eps(episode)
        return prob
        
        
        
    def b_action(self,state,episode):
        action = None
        p = np.random.uniform(0,1)
        if p < self.eps(episode): ## eps greedy
            action = np.random.randint(self.naction)
        else:
            action = np.argmax(self.Qb[state,:])
        return action


    def pi_action(self,state):
        action = np.argmax(self.Q[state,:])
        return action
        
    def reset(self):
        self.Q = np.zeros((self.nstate,self.naction))
        self.C = np.zeros((self.nstate,self.naction))

        