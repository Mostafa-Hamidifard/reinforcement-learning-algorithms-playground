import my_utils
from matplotlib import pyplot as plt
import numpy as np
num_eps = 750

file_name = "data_OFFMC_constant.pickle"
QCTE_mean_exp, QCTE_std_exp = my_utils.get_exp_reward(file_name)

file_name = "data_OFFMC_decreasing.pickle"
QDEC_mean_exp, QDEC_std_exp = my_utils.get_exp_reward(file_name)

x = np.arange(num_eps)
plt.figure(figsize=(10,8),dpi=250)
plt.plot(QCTE_mean_exp,label="OFFMC , EPS=cte")

plt.fill_between( x, QCTE_mean_exp - 1.96*QCTE_std_exp/np.sqrt(10),
                 QCTE_mean_exp + 1.96*QCTE_std_exp/np.sqrt(10), alpha=0.4, label="OFFMC , learningrate=cte , 95%")


plt.plot(QDEC_mean_exp,label="OFFMC , EPS=decreasing")

plt.fill_between( x, QDEC_mean_exp - 1.96*QDEC_std_exp/np.sqrt(10),
                 QDEC_mean_exp + 1.96*QDEC_std_exp/np.sqrt(10), alpha=0.4, label="OFFMC , learningrate=decreasing , 95%")

plt.grid(True)
plt.title("OFFMC, expected reward")
plt.legend()
plt.show()
file_name = "data_OFFMC_constant.pickle"
QCTE_mean_sum, QCTE_std_sum = my_utils.get_cum_reward(file_name)
file_name = "data_OFFMC_decreasing.pickle"
QDEC_mean_sum, QDEC_std_sum = my_utils.get_cum_reward(file_name)

x = np.arange(num_eps)
plt.figure(figsize=(10,8),dpi=250)
plt.plot(QCTE_mean_sum,label="OFFMC , EPS=cte")

plt.fill_between( x, QCTE_mean_sum - 1.96*QCTE_std_sum/np.sqrt(10),
                 QCTE_mean_sum + 1.96*QCTE_std_sum/np.sqrt(10), alpha=0.4, label="OFFMC , learningrate=cte , 95%")


plt.plot(QDEC_mean_sum,label="OFFMC , EPS=decreasing")

plt.fill_between( x, QDEC_mean_sum - 1.96*QDEC_std_sum/np.sqrt(10),
                 QDEC_mean_sum + 1.96*QDEC_std_sum/np.sqrt(10), alpha=0.4, label="OFFMC , learningrate=decreasing , 95%")

plt.grid(True)
plt.title("Offpolicy monte carlo, cumulative reward")
plt.legend()
plt.show()


