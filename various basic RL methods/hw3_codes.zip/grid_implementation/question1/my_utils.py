import pickle
import matplotlib.pyplot as plt
import numpy as np 

def draw_arrow(ax, direction,max_Q=None):
    # if direction == "left":
    # for checking with Q and plot: right:
    if direction == 0:
        begin = (0.8,0.5)
        end = (0.2,0.5)
    # elif direction == "right":
    # for checking with Q and plot: left:
    elif direction == 2:
        begin = (0.2,0.5)
        end = (0.8,0.5)
    # elif direction == "up":
    elif direction == 3:
        begin = (0.5,0.8)
        end = (0.5,0.2)
    # elif direction == "down":
    elif direction == 1:
        begin = (0.5,0.2)
        end = (0.5,0.8)
    ax.annotate("", xy=begin, xytext=end, textcoords='axes fraction',
                arrowprops=dict(arrowstyle='->', connectionstyle='arc3', color='red'))
    if max_Q!= None:
        ax.text(0.5, 0.5, np.round(max_Q,2), transform=ax.transAxes,
        fontsize=10, fontweight='bold', va='center', ha='center')
    
def plot_grid(size):
    fig, ax = plt.subplots(size,size,figsize=(7,7),dpi=200)
    for i in range(size):
        for j in range(size):
            ax[i,j].set_xticks([])
            ax[i,j].set_yticks([])
            # ax[i,j].text(0.5, 0.5, f"({i} , {j})", transform=ax[i,j].transAxes,
            # fontsize=14, fontweight='bold', va='center', ha='center')
    plt.subplots_adjust(hspace=0,wspace=0)
    return fig , ax
    

treeloc = np.array([[2., 4.] , [4., 4.] , [3. ,2.],[5., 2.],[2., 5.],[4. ,3.],[5., 5.],[1., 1.]])

# Specify the size of the grid
grid_size = 6
    
    


def state_converter(state,size):
    return state[0]*size + state[1]

def load_var(file_path):
    loaded_data = None
    with open(file_path, 'rb') as file:
        # Deserialize and retrieve the variable from the file
        loaded_data = pickle.load(file)
    return loaded_data

def save_var(file_path,data):
    with open(file_path, 'wb') as file:
        # Serialize and write the variable to the file
        pickle.dump(data, file)
        
        
def plot_found_path(size,agentQ,target_loc,start_loc,tree_loc):
    fig , axes = plot_grid(size)
    for loc in tree_loc:
        r = int(loc[1])
        c = int(loc[0])
        axes[r,c].set_facecolor('grey')
    axes[start_loc[1],start_loc[0]].set_facecolor('blue')
    axes[target_loc[1],target_loc[0]].set_facecolor('green')
    
    action_to_direction = {
            0: np.array([1, 0]), # right
            1: np.array([0, 1]), # up
            2: np.array([-1, 0]), # left
            3: np.array([0, -1]),} # down
    for i in range(size):
        for j in range(size):
            state = state_converter((i,j),size)
            action = np.argmax(agentQ[state,:])
            # direction = action_to_direction[action]
            direction = action
            draw_arrow(axes[j,i],direction,agentQ[state,action])
    return fig, axes


def get_exp_reward(filename):
    dic = load_var(filename)
    reward_store = dic["reward_store"]
    reward_store = np.array(reward_store)
    mean = np.mean(reward_store,axis=0).reshape((-1,))
    std = np.std(reward_store,axis=0).reshape((-1,))
    return mean,std

def get_cum_reward(filename):
    dic = load_var(filename)
    reward_store = dic["reward_store"]
    reward_store = np.array(reward_store)
    cumsum = np.cumsum(reward_store,axis=1)
    mean = np.mean(cumsum,axis=0).reshape((-1,))
    std = np.std(cumsum,axis=0).reshape((-1,))
    return mean,std
      
