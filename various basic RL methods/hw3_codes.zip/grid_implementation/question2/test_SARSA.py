import my_utils
## for Qlearning with decreasing alpha
Q_store = my_utils.load_var("data_sarsa.pickle")["Q_store"]

import environment_creation_final_version as envirnment
import numpy as np
import random
from SARSA import SARSA
from my_utils import state_converter,plot_found_path
from tqdm import tqdm
from matplotlib import pyplot as plt

naction = 4
size = 6
seed = 147
options = {"max_trial":10,"number_of_trees":8,"target_candid_locations": (0,1,2,6,7,12),"start_candid_locations":(23,28,29,33,34,35) }
    
np.random.seed(seed)
random.seed(seed)
"""----------------------------------------"""
total_num_episodes = 10

env = envirnment.GridWorldEnv(size=size,render_mode="human")
agent = SARSA(number_of_action=4,number_of_states=size**2
              ,dicount_factor=0.9,alpha=lambda x: 0,eps= lambda x: 0) # greedy with respect to Q
env.action_space.seed(seed)

#### importing Q after learning
agent.Q = Q_store[0]

reward_seq = np.zeros((total_num_episodes,))

for episode_idx in tqdm(range(1,total_num_episodes+1)):
    if episode_idx != 1:
        env.render_mode = None
        
    terminated = False
    truncated = False
    observation, info = env.reset(seed=seed,options=options)
    
    if episode_idx % total_num_episodes == 0:
        """necessary data for plotting arrow plot"""
        start_location = observation['agent']
        target_location = env._target_location
        tree_locations = env.tree_locs
        fig , ax = plot_found_path(size,agent.Q,target_location,start_location,tree_locations)
        fig.suptitle("SARSA")
        plt.show()  
    
    state = state_converter(observation['agent'],size)
    while not (terminated or truncated):
        """classic Qlearning loop"""    
        action = agent.take_action(state, episode_idx)
        (observation, reward, terminated, truncated, info) = env.step(action)
        state = state_converter(observation['agent'],size)
        
        reward_seq[episode_idx-1] += reward
        """---------------------------------------"""

mean = np.mean(reward_seq,axis=0)
std = np.std(reward_seq,axis=0)
print("###################")
print(f"SARSA: reward_mean={mean} , std={std}")

env.close()

