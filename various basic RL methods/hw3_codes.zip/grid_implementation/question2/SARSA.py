# -*- coding: utf-8 -*-
"""
Created on Tue Jan  2 13:30:12 2024

@author: Mostafa
"""
import numpy as np
class SARSA:
    
    def __init__(self,number_of_action,number_of_states,dicount_factor,alpha,eps):
        self.naction = number_of_action
        self.nstate = number_of_states
        self.gamma = dicount_factor
        self.alpha = alpha
        self.eps = eps
        # self.Q = np.random.normal(0,2,size=(self.nstate,self.naction))
        self.Q = np.zeros((self.nstate,self.naction))
        
        
    def update(self,pr_state,pr_action,next_state,next_action,reward,episode):
        S = pr_state
        A = pr_action
        Sprime = next_state
        Aprime = next_action
        self.Q[S,A] = self.Q[S,A] + self.alpha(episode) * (reward + self.gamma * self.Q[Sprime,Aprime] -self.Q[S,A])

    def take_action(self,state,episode):
        action = None
        p = np.random.uniform(0,1)
        if p < self.eps(episode): ## eps greedy
            action = np.random.randint(self.naction)
        else:
            action = np.argmax(self.Q[state,:])
        
        return action


    def take_operational_action(self,state):
        action = np.argmax(self.Q[state,:])
        return action
        
    def reset(self):
        self.Q = np.zeros((self.nstate,self.naction))


        