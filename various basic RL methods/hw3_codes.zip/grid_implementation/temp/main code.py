# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 12:36:04 2024

@author: Mostafa
"""

import environment_creation as envirnment
import pygame
import numpy as np
import random
from Qlearning import Qlearning
from my_utils import save_var,state_converter


def eps(nepisode):
    return 5/nepisode

def alpha(nepisode):
    return 0.1



naction = 4
size = 6
seed = 147
options = {"max_trial":750,"number_of_trees":8,"target_candid_locations": (0,1,2,6,7,12),"start_candid_locations":(23,28,29,33,34,35) }
    


"""
defining grid world and initialization
"""
env = envirnment.GridWorldEnv(size=size,render_mode='human')
np.random.seed(seed)
random.seed(seed)
env.action_space.seed(seed)
"""----------------------------------------"""

"""
defining agent
"""
agent = Qlearning(number_of_action=4,number_of_states=size**2
                  ,dicount_factor=0.9,alpha=alpha,eps=eps)
"""----------------------------------------"""


"""
Begin learning
"""

total_num_episodes = 750


G_list = []




for episode_idx in range(1,total_num_episodes+1):
    terminated = False
    truncated = False
    observation, info = env.reset(seed=seed,options=options)
    state_full = observation['agent']
    state = state_converter(state_full,size) ## maybe a problem
    sum_r = 0
    i = 0
    print(episode_idx)
    while not (terminated or i > 200):
        print(i)

        i=i+1
        """classic Qlearning loop"""    
        action = agent.take_action(state, episode_idx)
        
        (observation, reward, terminated, truncated, info) = env.step(action)
        state = state_converter(observation['agent'],size)
        agent.update(state,reward,episode_idx)
        """---------------------------------------"""
        
        sum_r += reward
    G_list.append(sum_r)


# env.close()    
# # waiting = True
# # while waiting:
# #     # Event loop
# #     for event in pygame.event.get():
# #         # i=i+1
# #         if event.type == pygame.QUIT:
# #             waiting= False
# # env.close()
# # env.close()