# -*- coding: utf-8 -*-
"""
Created on Tue Jan  2 15:13:00 2024

@author: Mostafa
"""

import matplotlib.pyplot as plt
from my_utils import load_var

G_list = load_var("Q_Glist.pickle")

plt.plot(G_list)
plt.show()

