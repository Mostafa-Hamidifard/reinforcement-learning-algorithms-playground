import environment_creation_final_version as envirnment
import numpy as np
import random
from my_utils import save_var,state_converter,plot_found_path
from tqdm import tqdm
from matplotlib import pyplot as plt



size = 6
seed = 147
options = {"max_trial":750,"number_of_trees":8,
           "target_candid_locations": (0,1,2,6,7,12),
           "start_candid_locations":(23,28,29,33,34,35) }

env = envirnment.GridWorldEnv(size=size,render_mode=None)
np.random.seed(seed)
random.seed(seed)
env.action_space.seed(seed)
observation, info = env.reset(seed,options)
"""----------------------------------------"""


naction = 4
nstate = size **2
gamma = 0.9
theta = 0.001

states = np.arange(nstate)
actions = np.arange(naction)
rewards = np.array([-1 , -0.5 , 25])
V = np.zeros(shape=(size,size))
DELTA = np.inf

while DELTA >= theta:
    DELTA = 0    
    for s in states:
        s1 = s//size
        s2 = s%size
        v = V[s1,s2]
        maxx = -np.inf
        for a in actions:
            summ = 0
            for sprime in states:
                for r in rewards:
                    PROB = env.probab(sprime,r,s,a)
                    summ +=  PROB* (r + gamma * V[sprime//size,sprime%size])
            maxx = max(maxx,summ)
            
        V[s1,s2] = maxx
        DELTA = max(DELTA,np.abs(v-V[s1,s2]))
        


## finding the optimal policy
Q = np.zeros((nstate,naction))

for s in states:
    for a in actions:
        summ = 0
        for sprime in states:
            for r in rewards:
                summ += env.probab(sprime,r,s,a) * (r + gamma * V[sprime//size,sprime%size])
        Q[s,a] = summ

save_var("data_VI.pickle", {"Q_store":Q})


start_location = observation['agent']
target_location = env._target_location
tree_locations = env.tree_locs
fig , ax = plot_found_path(size,Q,target_location,start_location,tree_locations)
fig.suptitle("Result")
plt.show()

