import my_utils
## for Qlearning with constant alpha
Q = my_utils.load_var("data_VI.pickle")["Q_store"]

import environment_creation_final_version as envirnment
import numpy as np
import random
from my_utils import state_converter,plot_found_path
from tqdm import tqdm
from matplotlib import pyplot as plt

def take_action(Q,state):
    action = np.argmax(Q[state,:])
    return action



naction = 4
size = 6
seed = 147
options = {"max_trial":10,"number_of_trees":8,"target_candid_locations": (0,1,2,6,7,12),"start_candid_locations":(23,28,29,33,34,35) }
    
np.random.seed(seed)
random.seed(seed)
"""----------------------------------------"""
total_num_episodes = 10

env = envirnment.GridWorldEnv(size=size,render_mode="human")
env.action_space.seed(seed)

#### importing Q after learning
reward_seq = np.zeros((total_num_episodes,))

for episode_idx in tqdm(range(1,total_num_episodes+1)):
    if episode_idx != 1:
        env.render_mode = None
        
    terminated = False
    truncated = False
    observation, info = env.reset(seed=seed,options=options)
    
    if episode_idx % total_num_episodes == 0:
        """necessary data for plotting arrow plot"""
        start_location = observation['agent']
        target_location = env._target_location
        tree_locations = env.tree_locs
        fig , ax = plot_found_path(size,Q,target_location,start_location,tree_locations)
        fig.suptitle("Value Iteration")
        plt.show()  
    
    state = state_converter(observation['agent'],size)
    while not (terminated or truncated):
        action = take_action(Q,state)
        (observation, reward, terminated, truncated, info) = env.step(action)
        state = state_converter(observation['agent'],size)
        
        reward_seq[episode_idx-1] += reward
        """---------------------------------------"""

mean = np.mean(reward_seq,axis=0)
std = np.std(reward_seq,axis=0)
print("###################")
print(f"Value iteration: reward_mean={mean} , std={std}")

env.close()

