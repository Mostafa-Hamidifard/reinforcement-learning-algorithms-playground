# -*- coding: utf-8 -*-
"""
Created on Mon Jan  1 12:36:04 2024

@author: Mostafa
"""

import environment_creation_final_version as envirnment
import numpy as np
import random
from Qlearning import Qlearning
from my_utils import save_var,state_converter
from tqdm import tqdm
from matplotlib import pyplot as plt

def eps(nepisode):
    return (0.1)**nepisode

def alpha(nepisode):
    # return 0.1/nepisode
    return 0.1/nepisode**0.5



naction = 4
size = 6
seed = 147
options = {"max_trial":750,"number_of_trees":8,"target_candid_locations": (0,1,2,6,7,12),"start_candid_locations":(23,28,29,33,34,35) }
    


"""
defining grid world and initialization
"""
env = envirnment.GridWorldEnv(size=size,render_mode=None)
np.random.seed(seed)
random.seed(seed)
env.action_space.seed(seed)
"""----------------------------------------"""

total_num_episodes = 750
reward_store = []
Q_store = []

for sl in tqdm(range(10)):
    env = envirnment.GridWorldEnv(size=size,render_mode=None)
    agent = Qlearning(number_of_action=4,number_of_states=size**2
                  ,dicount_factor=0.9,alpha=alpha,eps=eps)
    ## variables to save
    reward_seq = np.zeros((total_num_episodes,))
    agent_Q = None
    ## begining learning
    
    for episode_idx in tqdm(range(1,total_num_episodes+1)):
        terminated = False
        truncated = False
        observation, info = env.reset(seed=seed,options=options)
                
        
        """begining learning"""
        state = state_converter(observation['agent'],size)
        while not (terminated or truncated):
            """classic Qlearning loop"""    
            action = agent.take_action(state, episode_idx)
            (observation, reward, terminated, truncated, info) = env.step(action)
            state = state_converter(observation['agent'],size)
            agent.update(state,reward,episode_idx)
            
            reward_seq[episode_idx-1] += reward
            """---------------------------------------"""
    reward_store.append(reward_seq)
    Q_store.append(agent.Q)
    
save_var("data_Qlearning_decreasing.pickle", {"reward_store":reward_store,"Q_store":Q_store})



