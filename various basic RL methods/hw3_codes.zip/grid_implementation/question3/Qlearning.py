# -*- coding: utf-8 -*-

import numpy as np
class Qlearning:
    
    def __init__(self,number_of_action,number_of_states,dicount_factor,alpha,eps):
        self.naction = number_of_action
        self.nstate = number_of_states
        self.gamma = dicount_factor
        self.alpha = alpha
        self.eps = eps
        # self.Q = np.random.normal(0,2,size=(self.nstate,self.naction))
        self.Q = np.zeros((self.nstate,self.naction))
        
        self.current_action = None
        self.current_state = None
        
    def update(self,next_state,reward,episode):
        S = self.current_state
        A = self.current_action
        Sprime = next_state
        self.Q[S,A] = self.Q[S,A] + self.alpha(episode) * (reward + self.gamma * np.argmax(self.Q[Sprime,:])-self.Q[S,A])

    def take_action(self,state,episode):
        action = None
        p = np.random.uniform(0,1)
        if p < self.eps(episode): ## eps greedy
            action = np.random.randint(self.naction)
        else:
            action = np.argmax(self.Q[state,:])
        
        self.current_state = state
        self.current_action = action
        return self.current_action


    def take_operational_action(self,state):
        action = np.argmax(self.Q[state,:])
        self.current_action = action
        return action
        
    def reset(self):
        self.Q = np.zeros((self.nstate,self.naction))
        self.current_action = None
        self.current_state = None

        