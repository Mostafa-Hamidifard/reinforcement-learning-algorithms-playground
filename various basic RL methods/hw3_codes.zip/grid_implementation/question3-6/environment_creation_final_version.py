import numpy as np
import pygame
import gymnasium as gym
from gymnasium import spaces
import random


class GridWorldEnv(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 10000}


    def is_tree_loc(self,loc):
        for tree in self.tree_locs:
            if np.array_equal(loc, tree):
                return 1
        return 0



    def probab(self,sprime,r,s,a):
        print(f"sprime: {sprime} , r: {r} , s: {s} , a: {a} ")
        direction = self._action_to_direction[a]
        sprime_2d = np.array([sprime//self.size , sprime%self.size])        
        s_2d = np.array([s//self.size , s%self.size])        
        
        ## checking if s_2d is valid -> it cant be on target and tree locations
        if self.is_tree_loc(s_2d):
            return 0
        if self.is_tree_loc(sprime_2d):
            return 0
        
        if np.array_equal(s_2d , self._target_location):
            return 0
        # so s_2d was an empty tile
        if np.array_equal(sprime_2d , s_2d):
            if r == -0.5:
                return 0.1
            if r == -1:
                p = 0    
                if self.is_tree_loc(s_2d + direction):
                    p = p + 0.8    
                if self.is_tree_loc(s_2d - direction):
                    p = p + 0.1
                return p
            if r==25:
                return 0
            """HERE IT GOES""" 
  
        elif np.array_equal(sprime_2d , s_2d - direction):
            if r==-1:
                return 0
            elif r==-0.5:
                if self.is_tree_loc(sprime_2d):
                    return 0
                if np.array_equal(self._target_location, sprime_2d):
                    return 0
                return 0.1
                
            elif r==25:
                if np.array_equal(self._target_location, sprime_2d):
                    return 0.1
                else:
                    return 0
            else:
                raise Exception("Problem with dynamics")
        elif np.array_equal(sprime_2d , s_2d + direction):
            if r==-1:
                return 0
            elif r==-0.5:
                if self.is_tree_loc(sprime_2d):
                    return 0
                if np.array_equal(self._target_location, sprime_2d):
                    return 0
                return 0.8
            elif r==25:
                if np.array_equal(self._target_location, sprime_2d):
                    return 0.8
                else:
                    return 0
            else:
                raise Exception("Problem with dynamics")
        else:
           return 0
           
           

    def __init__(self, render_mode=None, size=6):
        self.size = size  # The size of the square grid
        self.window_size = 512  # The size of the PyGame window

        
        self.observation_space = spaces.Dict(
            {
                "agent": spaces.Box(0, size - 1, shape=(2,), dtype=int),
                "target": spaces.Box(0, size - 1, shape=(2,), dtype=int),
            }
        )

        # We have 4 actions, corresponding to "right", "up", "left", "down"
        self.action_space = spaces.Discrete(4)
        self._action_to_direction = {
            0: np.array([1, 0]),
            1: np.array([0, 1]),
            2: np.array([-1, 0]),
            3: np.array([0, -1]),
        }

        assert render_mode is None or render_mode in self.metadata["render_modes"]
        self.render_mode = render_mode

        self.window = None
        self.clock = None


    def _get_obs(self):
        return {"agent": self._agent_location, "target": self._target_location}


    def _get_info(self):
        return {
            "distance": np.linalg.norm(
                self._agent_location - self._target_location, ord=1)
        }


    def reset(self, seed=None, options=None):
        self.battery = 100
        self.health = 100
        self.options = options
        # We need the following line to seed self.np_random
        super().reset(seed=seed)
        
        self.tree_locs = self.config_obj_locs()
        

        observation = self._get_obs()
        info = self._get_info()

        if self.render_mode == "human":
            self._render_frame()

        return observation, info

    """THIS HAS CHANGED"""
    def get_reward(self,situation):
        if situation == "tree_collision":
            return np.random.normal(loc=-1,scale=0.5)
        elif situation == "valid":
            return np.random.normal(loc=-0.5,scale=0.25)
        elif situation == "reached":
            return np.random.normal(loc=25,scale=5)
        else:
            raise Exception("No defined situation!")
        

    def step(self, action):
        truncated = False
        
        self.battery = self.battery - np.random.normal(loc=0.35,scale=0.15)
        
        last_place = self._agent_location
        
        """
        I should change this after I complete algorithms
        """
        if np.array_equal(self._agent_location, self._target_location):
            observation = self._get_obs()
            info = self._get_info()
            
            if self.battery < 5 or self.health < 15:
                truncated = True    
            terminated = True
            return observation,self.get_reward("reached"),terminated, truncated, info
            
        
        # Map the action (element of {0,1,2,3}) to the direction we walk in        
        direction = self._action_to_direction[action]
                        
        p = np.random.uniform(0,1);        
        if p < 0.1:
            direction = - direction
        elif p < 0.2:
            direction = 0 * direction
        ####
        # We use `np.clip` to make sure we don't leave the grid
        next_place = np.clip(
            self._agent_location + direction, 0, self.size - 1
        )
        situation = "valid"
        ## checking tree collision
        for tree in self.tree_locs:
            if np.array_equal(next_place, tree):
                next_place = last_place
                situation = "tree_collision"
                self.health = self.health - np.random.normal(loc=0.2,scale=0.1)
                break
        
        self._agent_location = next_place
        if np.array_equal(self._agent_location, self._target_location):
            situation = "reached"
            
        reward = self.get_reward(situation)
        
        # An episode is done iff the agent has reached the target
        terminated = np.array_equal(self._agent_location, self._target_location)

        observation = self._get_obs()
        info = self._get_info()

        if self.render_mode == "human":
            self._render_frame()
        
        if self.battery < 5 or self.health < 15:
            truncated = True 
        return observation, reward, terminated, truncated, info



    def config_obj_locs(self):
        options = self.options
        numtree = options["number_of_trees"]
        start_locs = options["start_candid_locations"]
        target_locs = options["target_candid_locations"]

        # Choose the agent's location uniformly at random
        self._agent_location = self.np_random.choice(start_locs,size=1)
        self._target_location = self.np_random.choice(target_locs,size=1)
        
        tree_candid_locations = np.array([i for i in range(self.size**2) if i not in [self._agent_location,self._target_location]])
        
        final_tree_locations = np.array([])

        
        for i in range(numtree):
            flag = True
            while flag:
                if len(tree_candid_locations) == 0:
                    raise IndexError("tree candid Locations is empty")
                    
                candid_loc = self.np_random.choice(tree_candid_locations,size=1)
                
                if candid_loc in final_tree_locations:
                    tree_candid_locations = np.delete(
                        tree_candid_locations,
                        np.where(tree_candid_locations == candid_loc))
                    continue
                
                temp = np.append(final_tree_locations,candid_loc)
                
                ## checking near wall
                divar = 0
                for cc in temp:
                    width = cc // self.size
                    
                    height = cc % self.size
                    if width == 0 or height == 0 or (height == self.size-1) or (width == self.size-1) :
                        divar += 1
                if divar >= 3:
                    tree_candid_locations = np.delete(
                        tree_candid_locations,
                        np.where(tree_candid_locations == candid_loc))
                    continue
                ## checking being together
                together_found = False
                together = 0
                for m in range(len(temp)):
                    cc = temp[m]
                    ccwidth = cc // self.size
                    ccheight = cc % self.size

                    for n in range(m+1,len(temp)):
                        # if cc == jj:
                        #     continue
                        jj = temp[n]
                        
                        jjwidth = jj // self.size
                        jjheight = jj % self.size
                        
                        if jjwidth+1 == ccwidth and jjheight == ccheight:
                            together +=1
                        elif jjwidth-1 == ccwidth and jjheight == ccheight:
                            together +=1
                        elif jjwidth == ccwidth and jjheight+1 == ccheight:
                            together +=1
                        elif jjwidth == ccwidth and jjheight-1 == ccheight:
                            together +=1
                        if together >= 2:
                            break
                    if together >= 2:
                        tree_candid_locations = np.delete(
                            tree_candid_locations,
                            np.where(tree_candid_locations == candid_loc))
                        together_found = True
                        break
                    #     if jjwidth+1 == ccwidth and jjheight == ccheight:
                    #         together_found = True
                    #         break
                    #     elif jjwidth-1 == ccwidth and jjheight == ccheight:
                    #         together_found = True
                    #         break
                    #     elif jjwidth == ccwidth and jjheight+1 == ccheight:
                    #         together_found = True
                    #         break
                    #     elif jjwidth == ccwidth and jjheight-1 == ccheight:
                    #         together_found = True
                    #         break
                    # if together_found:
                    #     tree_candid_locations = np.delete(
                    #         tree_candid_locations,
                    #         np.where(tree_candid_locations == candid_loc))
                    #     break
                if together_found == False:
                    final_tree_locations = temp.copy()
                    tree_candid_locations = np.delete(
                        tree_candid_locations,
                        np.where(tree_candid_locations == candid_loc))
                    flag = False
        
        
        self._agent_location = np.array((self._agent_location//self.size,self._agent_location%self.size))
        self._agent_location = self._agent_location.reshape((-1,))
        self._target_location = np.array((self._target_location//self.size,self._target_location%self.size))
        self._target_location = self._target_location.reshape((-1,))

        
        ss = []
        for i in range(numtree):
            ss.append((final_tree_locations[i]//self.size,final_tree_locations[i]%self.size))
        final_tree_locations = np.array(ss)
        
        return final_tree_locations
                


    def render(self):
        if self.render_mode == "rgb_array":
            return self._render_frame()

    def _render_frame(self):
        if self.window is None and self.render_mode == "human":
            pygame.init()
            pygame.display.init()
            self.window = pygame.display.set_mode(
                (self.window_size, self.window_size)
            )
        if self.clock is None and self.render_mode == "human":
            self.clock = pygame.time.Clock()

        canvas = pygame.Surface((self.window_size, self.window_size))
        canvas.fill((255, 255, 255))
        pix_square_size = (
            self.window_size / self.size
        )  # The size of a single grid square in pixels

        # First we draw the target
        pygame.draw.rect(
            canvas,
            (255, 0, 0),
            pygame.Rect(
                pix_square_size * self._target_location,
                (pix_square_size, pix_square_size),
            ),
        )
        # next we draw the agent
        pygame.draw.circle(
            canvas,
            (0, 0, 255),
            (self._agent_location + 0.5) * pix_square_size,
            pix_square_size / 3,
        )

        for tr_idx in range(self.options['number_of_trees']):
            pygame.draw.rect(
                canvas,
                (0, 0, 0),
                pygame.Rect(
                    pix_square_size * self.tree_locs[tr_idx,:].reshape((-1,)),
                    (pix_square_size, pix_square_size),
                ),
            )


        # Finally, add some gridlines
        for x in range(self.size + 1):
            pygame.draw.line(
                canvas,
                0,
                (0, pix_square_size * x),
                (self.window_size, pix_square_size * x),
                width=3,
            )
            pygame.draw.line(
                canvas,
                0,
                (pix_square_size * x, 0),
                (pix_square_size * x, self.window_size),
                width=3,
            )

        if self.render_mode == "human":
            # The following line copies our drawings from `canvas` to the visible window
            self.window.blit(canvas, canvas.get_rect())
            pygame.event.pump()
            pygame.display.update()

            # We need to ensure that human-rendering occurs at the predefined framerate.
            # The following line will automatically add a delay to keep the framerate stable.
            self.clock.tick(self.metadata["render_fps"])
        else:  # rgb_array
            return np.transpose(
                np.array(pygame.surfarray.pixels3d(canvas)), axes=(1, 0, 2)
            )



    def close(self):
        if self.window is not None:
            pygame.display.quit()
            pygame.quit()
