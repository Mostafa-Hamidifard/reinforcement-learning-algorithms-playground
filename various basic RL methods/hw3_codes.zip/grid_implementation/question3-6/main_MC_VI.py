import environment_creation_final_version as envirnment
import numpy as np
import random
from my_utils import save_var,state_converter,plot_found_path
from tqdm import tqdm
from matplotlib import pyplot as plt


def perform_MC(env,total_num_episodes):
    sumreward_seq = np.zeros((total_num_episodes,))
    
    mc_state_episode = []
    mc_action_episode = []
    mc_reward_episode = []
    
    for episode_idx in tqdm(range(1,total_num_episodes+1)):
        terminated = False
        truncated = False
        observation, info = env.reset(seed=seed,options=options)
        mc_state_seq = np.array([])
        mc_action_seq = np.array([])
        mc_reward_seq = np.array([])

        while not (terminated or truncated):
            state = state_converter(observation['agent'],size)
            action = env.action_space.sample()
            mc_state_seq= np.append(mc_state_seq,state)
            mc_action_seq = np.append(mc_action_seq,action)        

            (observation, reward, terminated, truncated, info) = env.step(action)

            mc_reward_seq = np.append(mc_reward_seq,reward)        
            """---------------------------------------"""
            sumreward_seq[episode_idx-1] += reward
        mc_state_episode.append(mc_state_seq)
        mc_action_episode.append(mc_action_seq)
        mc_reward_episode.append(mc_reward_seq)
    
    
    return mc_state_episode,mc_action_episode,mc_reward_episode,sumreward_seq


def perform_VI(probab,rew,start_location,target_location,tree_locations):
    naction = 4
    nstate = size **2
    gamma = 0.9
    theta = 0.1

    states = np.arange(nstate)
    actions = np.arange(naction)
    rewards = np.unique(rew)
    V = np.zeros(shape=(size,size))
    DELTA = np.inf

    while DELTA >= theta:
        DELTA = 0    
        for s in states:
            s1 = s//size
            s2 = s%size
            v = V[s1,s2]
            maxx = -np.inf
            for a in actions:
                summ = 0
                for sprime in states:
                    for r in rewards:
                        PROB = probab[s,sprime,a]
                        if r == rew[s,sprime,a]:
                            PROB = 0
                        summ +=  PROB* (r + gamma * V[sprime//size,sprime%size])
                maxx = max(maxx,summ)
            
            V[s1,s2] = maxx
            DELTA = max(DELTA,np.abs(v-V[s1,s2]))
        


    ## finding the optimal policy
    Q = np.zeros((nstate,naction))
    for s in states:
        s = int(s)
        for a in actions:
            a = int(a)
            summ = 0
            for sprime in states:
                for r in rewards:
                    PROB = probab[s,sprime,a]
                    if r == rew[s,sprime,a]:
                        PROB = 0
                    summ += PROB * (r + gamma * V[sprime//size,sprime%size])
            Q[s,a] = summ
    
    fig , ax = plot_found_path(size,Q,target_location,start_location,tree_locations)
    fig.suptitle("Result")
    plt.show()
    


def find_dynamics(state_episode,action_episode,reward_episode):
    size = 6
    nstate = size**2
    naction = 4
    
    dyn = np.zeros((nstate,nstate,naction)) # s sprime a 
    cnt = np.zeros((nstate,naction)) # s a
    rew = np.zeros((nstate,nstate,naction)) # s sprime a
    for j in range(len(state_episode)):
        mc_state_seq = state_episode[j]
        mc_action_seq = action_episode[j]
        mc_reward_seq = mc_reward_episode[j]
        
        for i in range(len(mc_state_seq)-1):
            s = int(mc_state_seq[i])
            sprime = int(mc_state_seq[i+1])
            a = int(mc_action_seq[i])
            rew[s,sprime,a]= rew[s,sprime,a] +  mc_reward_seq[i]
            cnt[s,a] = cnt[s,a]+ 1
            dyn[s,sprime,a]=dyn[s,sprime,a] + 1
        
    for s in range(nstate):
        for sprime in tqdm(range(nstate)):
            for a in range(naction):
                if cnt[s,a] == 0:
                    continue
                dyn[s,sprime,a] = dyn[s,sprime,a] / cnt[s,a] 
                rew[s,sprime,a] = rew[s,sprime,a] / cnt[s,a]
                
    return dyn , rew



size = 6
seed = 147
options = {"max_trial":750,"number_of_trees":8,
           "target_candid_locations": (0,1,2,6,7,12),
           "start_candid_locations":(23,28,29,33,34,35) }

env = envirnment.GridWorldEnv(size=size,render_mode=None)
np.random.seed(seed)
random.seed(seed)
env.action_space.seed(seed)
observation, info = env.reset(seed,options)
"""----------------------------------------"""
start_location = observation['agent']
target_location = env._target_location
tree_locations = env.tree_locs

mc_state_episode,mc_action_episode,mc_reward_episode,sumreward_seq = perform_MC(env,750)

dyn, rew = find_dynamics(mc_state_episode,mc_action_episode,mc_reward_episode)


perform_VI(dyn,rew,start_location,target_location,tree_locations)



